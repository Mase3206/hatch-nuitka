# hatch-nuitka

[![PyPI - Version](https://img.shields.io/pypi/v/hatch-nuitka.svg)](https://pypi.org/project/hatch-nuitka)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/hatch-nuitka.svg)](https://pypi.org/project/hatch-nuitka)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install hatch-nuitka
```

## License

`hatch-nuitka` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
